document.documentElement.classList.add('js');
(function(){
  // Apertura palabra a palabra
  const h1 = document.getElementById('frase');
  const walk = n => [...n.childNodes].forEach(c => {
    if (c.nodeType === 3) {
      const f = document.createDocumentFragment();
      c.textContent.split(/(\s+)/).forEach(t => { if (!t) return;
        if (/^\s+$/.test(t)) f.appendChild(document.createTextNode(t));
        else { const s = document.createElement('span'); s.className = 'w'; s.textContent = t; f.appendChild(s); } });
      c.replaceWith(f);
    } else walk(c);
  });
  walk(h1);
  h1.querySelectorAll('.w').forEach((w, i) => setTimeout(() => w.classList.add('on'), 300 + i * 190));

  // Revelados
  const todos = document.querySelectorAll('.rv, .paso');
  const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add('on'); io.unobserve(e.target); } }), { threshold: .2 });
  todos.forEach(el => io.observe(el));
  setTimeout(() => todos.forEach(el => el.classList.add('on')), 6000);


  // Progreso y halo
  const prog = document.getElementById('progreso'), halo = document.getElementById('halo');
  addEventListener('scroll', () => { const h = document.documentElement.scrollHeight - innerHeight; prog.style.setProperty('--p', h > 0 ? scrollY / h : 0); }, { passive: true });
  addEventListener('pointermove', e => { halo.style.setProperty('--mx', e.clientX + 'px'); halo.style.setProperty('--my', e.clientY + 'px'); }, { passive: true });

  // Ingeniería de procesos: antes / rediseñado
  const fd = document.getElementById('flujoDemo');
  fd.querySelectorAll('.fd-toggle button').forEach(b => b.addEventListener('click', () => {
    fd.dataset.modo = b.dataset.modo;
    fd.querySelectorAll('.fd-toggle button').forEach(x => x.classList.toggle('on', x === b));
  }));

  // Tarjetas del efecto miércoles
  document.querySelectorAll('.giro').forEach(g => g.addEventListener('click', () => {
    const on = g.classList.toggle('on'); g.setAttribute('aria-pressed', on);
  }));

  // Escalera de niveles: la línea se ilumina al bajar
  const esc = document.getElementById('escalera');
  const pintaEsc = () => { const r = esc.getBoundingClientRect(); const p = Math.min(1, Math.max(0, (innerHeight * .6 - r.top) / r.height)); esc.style.setProperty('--prog', p.toFixed(3)); };
  addEventListener('scroll', pintaEsc, { passive: true }); pintaEsc();

  // Cabecera
  const top = document.getElementById('top'); let last = 0;
  addEventListener('scroll', () => { const y = scrollY; top.classList.toggle('scrolled', y > 40); top.classList.toggle('hidden', y > 500 && y > last); last = y; }, { passive: true });

  // Pregunta
  const resp = document.getElementById('respuesta'), red = document.getElementById('red');
  document.querySelectorAll('.opcion').forEach(b => b.addEventListener('click', () => {
    document.querySelectorAll('.opcion').forEach(o => o.classList.remove('sel'));
    b.classList.add('sel'); resp.classList.remove('on');
    setTimeout(() => { resp.classList.add('on'); red.classList.add('on'); }, 120);
  }));

  // Carrusel
  const pista = document.getElementById('pistaC'), puntos = [...document.querySelectorAll('#puntos i')];
  const diapos = [...pista.children];
  const actual = () => { const c = pista.scrollLeft + pista.clientWidth / 2; let best = 0, d = 1e9;
    diapos.forEach((s, i) => { const m = s.offsetLeft + s.clientWidth / 2; if (Math.abs(m - c) < d) { d = Math.abs(m - c); best = i; } }); return best; };
  const ir = i => { const s = diapos[(i + diapos.length) % diapos.length]; pista.scrollTo({ left: s.offsetLeft - (pista.clientWidth - s.clientWidth) / 2, behavior: 'smooth' }); };
  pista.addEventListener('scroll', () => { const a = actual(); puntos.forEach((p, i) => p.classList.toggle('on', i === a)); }, { passive: true });
  document.querySelectorAll('.flechas button').forEach(b => b.addEventListener('click', () => ir(actual() + +b.dataset.dir)));
  let auto = setInterval(() => ir(actual() + 1), 5000);
  pista.addEventListener('pointerdown', () => clearInterval(auto), { once: true });

  // Antes / Después
  const comp = document.getElementById('comp');
  comp.querySelector('input').addEventListener('input', e => comp.style.setProperty('--x', e.target.value + '%'));

  // FAQ
  const fe = document.getElementById('faq-equipo');
  fe.addEventListener('toggle', () => { const m = fe.querySelector('.faq-mascota'); if (fe.open) { m.style.animation = 'none'; m.offsetHeight; m.style.animation = ''; } });

  // Formulario simulado
  const modal = document.getElementById('modal'), form = document.getElementById('form');
  const pForm = document.getElementById('paso-form'), pOk = document.getElementById('paso-ok'), err = document.getElementById('error');
  let lastFocus = null;
  const abrir = () => { lastFocus = document.activeElement; pForm.style.display = ''; pOk.style.display = 'none'; err.textContent = ''; form.reset();
    modal.classList.add('open'); document.body.style.overflow = 'hidden'; setTimeout(() => form.querySelector('input').focus({ preventScroll: true }), 300); };
  const cerrar = () => { modal.classList.remove('open'); document.body.style.overflow = ''; lastFocus && lastFocus.focus(); };
  document.querySelectorAll('[data-abrir]').forEach(b => b.addEventListener('click', abrir));
  if (location.hash === '#diagnostico') setTimeout(abrir, 400);
  modal.addEventListener('click', e => { if (e.target === modal || e.target.closest('[data-cerrar]')) cerrar(); });
  addEventListener('keydown', e => { if (e.key === 'Escape' && modal.classList.contains('open')) cerrar(); });
  form.addEventListener('submit', e => { e.preventDefault(); const f = form.elements;
    if (!f.nombre.value.trim() || !f.empresa.value.trim() || !f.sector.value || !f.contacto.value.trim()) { err.textContent = 'Completa los campos obligatorios, por favor.'; return; }
    if (!f.rgpd.checked) { err.textContent = 'Necesitamos que aceptes la política de privacidad.'; return; }
    enviar(form, err).then(ok => { if (ok) { pForm.style.display = 'none'; pOk.style.display = 'block'; } }); });

  // Envío de formularios al servidor de la web
  async function enviar(formulario, aviso) {
    const boton = formulario.querySelector('button[type=submit]');
    const texto = boton.innerHTML; boton.disabled = true; boton.textContent = 'Enviando…';
    const datos = new FormData(formulario); datos.set('rgpd', '1');
    try {
      const r = await fetch('/api/enviar.php', { method: 'POST', body: datos, headers: { 'Accept': 'application/json' } });
      const j = await r.json().catch(() => ({}));
      if (r.ok && j.ok) { window.nylandLead && window.nylandLead(datos.get('tipo')); return true; }
      aviso.textContent = j.error || 'No hemos podido enviarlo. Escríbenos a contacto@nylandconsulting.es.';
    } catch (e) { aviso.textContent = 'Sin conexión. Inténtalo de nuevo o escríbenos a contacto@nylandconsulting.es.'; }
    finally { boton.disabled = false; boton.innerHTML = texto; }
    return false;
  }

  // Guía gratuita
  const gf = document.getElementById('guiaForm'), gok = document.getElementById('guiaOk');
  gf.addEventListener('submit', e => { e.preventDefault(); gok.classList.remove('bien');
    const em = gf.elements.email.value.trim();
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(em)) { gok.textContent = 'Revisa tu email, por favor.'; return; }
    if (!document.getElementById('guiaRgpd').checked) { gok.textContent = 'Necesitamos que aceptes la política de privacidad.'; return; }
    gok.textContent = '';
    enviar(gf, gok).then(ok => { if (ok) { gok.classList.add('bien'); gok.textContent = '¡Listo! Revisa tu correo: te hemos enviado un email para confirmar y, al confirmar, recibirás la guía.'; gf.reset(); } }); });
})();

(function(){
  const raiz = document.getElementById('forja'); if (!raiz) return;
  const A = [
    ['presupuestos','Presupuestos que nadie vuelve a llamar','Un presupuesto sin seguimiento no suele ser un «no». Casi siempre es un «se me pasó». Y lo que el cliente recuerda no es el precio: es cómo le hiciste sentir.','ningún presupuesto se enfría'],
    ['mensajes','Mensajes repartidos en mil sitios','Tu marca no es tu logo. Es cómo contesta tu equipo un mensaje a las 13:47 de un miércoles, con todo lleno.','cada cliente recibe respuesta a tiempo y con vuestro tono'],
    ['persona','Todo depende de lo que sabe una persona','Si un proceso solo vive en la cabeza de alguien, no es un proceso: es un riesgo con nombre y apellidos. Y esa persona lo sabe, y le pesa.','el saber del equipo está al alcance de todos'],
    ['manera','Cada uno lo hace a su manera','No es falta de disciplina: es que nadie ha escrito todavía vuestra manera. Cuando existe, el equipo la defiende como propia.','cada proceso tiene vuestra forma de hacer'],
    ['quemado','El equipo va quemado','El cansancio rara vez viene del trabajo duro. Viene del trabajo inútil: repetir, buscar, perseguir. Es lo primero que quitamos.','el equipo trabaja con calma y con sentido'],
    ['dia','Hay un día en que todo cuesta más','Tu día malo de la semana casi nunca es culpa de las personas. Es un proceso que se atasca siempre en el mismo sitio.','todos los días de la semana rinden igual'],
    ['fuegos','La dirección apaga fuegos en vez de dirigir','Si diriges apagando fuegos, tu empresa ha aprendido a necesitarte para todo. La meta no es trabajar más: es que no haga falta que estés en cada decisión.','la dirección dirige en lugar de apagar fuegos'],
    ['vuelven','Clientes que no vuelven','Un cliente que no vuelve casi nunca se queja: simplemente se va. La experiencia que no diseñas tú la diseña el azar.','cada cliente quiere volver']
  ];
  const R = {
    'Cercana':['cercana','¡Hola, Marta! Te escribimos para saber qué tal sigues después de la visita. Si te surge cualquier duda, aquí estamos, como siempre.'],
    'Impecable':['impecable','Buenos días, Marta. Le confirmamos su cita del jueves a las 10:00. Lo tenemos todo preparado para que no tenga que esperar.'],
    'Ágil':['ágil','Hola, Marta: tu cita queda confirmada para el jueves a las 10:00. ¿Necesitas cambiarla? Responde a este mensaje y lo hacemos al momento.'],
    'Serena':['serena','Hola, Marta. Sin prisa: cuando te venga bien, revisa el presupuesto con calma. Si quieres, lo comentamos por teléfono cuando prefieras.'],
    'Cálida':['cálida','¡Marta, qué alegría verte la semana pasada! Te dejamos por aquí los cuidados que comentamos. Cuídate mucho.'],
    'Rigurosa':['rigurosa','Hola, Marta. Adjuntamos el presupuesto detallado, con cada fase y su plazo. Quedamos a tu disposición para cualquier aclaración.'],
    'Innovadora':['innovadora','Hola, Marta. Ya puedes ver tu presupuesto, reservar y pagar desde el móvil en un minuto. Te dejamos el enlace aquí.'],
    'Valiente':['valiente','Hola, Marta. Te hablamos claro: este es el tratamiento que de verdad te recomendamos y por qué. La decisión es tuya, y te acompañamos.']
  };
  const sel = new Set(), ras = [];
  const $ = id => document.getElementById(id);
  const chip = (txt, on) => { const b = document.createElement('button'); b.type = 'button'; b.className = 'chip'; b.textContent = txt; b.setAttribute('aria-pressed', 'false'); b.addEventListener('click', () => on(b)); return b; };
  A.forEach(a => $('atascos').appendChild(chip(a[1], b => {
    const on = !sel.has(a[0]); on ? sel.add(a[0]) : sel.delete(a[0]); b.setAttribute('aria-pressed', on);
    $('puertasF').innerHTML = ''; A.filter(x => sel.has(x[0])).forEach(x => { const d = document.createElement('div'); d.className = 'puerta-f'; d.innerHTML = '<small>Lo que quizá no habías pensado</small><p></p>'; d.querySelector('p').textContent = x[2]; $('puertasF').appendChild(d); });
    $('sig1').disabled = !sel.size; $('nota1').textContent = sel.size ? sel.size + (sel.size === 1 ? ' puerta abierta' : ' puertas abiertas') : 'Elige al menos uno para seguir.';
  })));
  Object.keys(R).forEach(r => $('rasgos').appendChild(chip(r, b => {
    const i = ras.indexOf(r);
    if (i > -1) ras.splice(i, 1); else { if (ras.length === 3) return; ras.push(r); }
    document.querySelectorAll('#rasgos .chip').forEach(c => c.setAttribute('aria-pressed', ras.includes(c.textContent)));
    $('sig2').disabled = !ras.length;
  })));
  const paso = n => { raiz.querySelectorAll('[data-paso]').forEach(p => p.hidden = p.dataset.paso != n); raiz.querySelectorAll('.forja-pasos span').forEach(s => s.classList.toggle('on', s.dataset.p <= n)); };
  const lista = a => a.length < 2 ? a.join('') : a.slice(0, -1).join(', ') + ' y ' + a[a.length - 1];
  const pinta = () => {
    const at = A.filter(x => sel.has(x[0])), adj = ras.map(r => R[r][0]);
    const m = $('manifiestoF'); m.textContent = 'Una empresa ' + lista(adj) + ', donde '; const em = document.createElement('em'); em.textContent = lista(at.slice(0, 3).map(x => x[3])) + '.'; m.appendChild(em);
    $('dentroF').innerHTML = ''; ['Cada persona sabe cómo se hacen las cosas aquí, y por qué.', 'Menos tareas repetidas, más tiempo para lo que da sentido a su trabajo.', 'Un equipo que siente los procesos como suyos, porque se han construido escuchándole.'].forEach(t => { const li = document.createElement('li'); li.textContent = t; $('dentroF').appendChild(li); });
    $('fueraF').textContent = 'Clientes, proveedores y hasta futuros trabajadores notan una forma de trabajar ' + lista(adj) + '. Eso no se copia con una herramienta: es vuestra marca en el sector.';
    $('tonoF').textContent = R[ras[0]][1];
  };
  $('sig1').addEventListener('click', () => paso(2));
  $('atr2').addEventListener('click', () => paso(1));
  $('sig2').addEventListener('click', () => { pinta(); paso(3); raiz.scrollIntoView({ behavior: 'smooth', block: 'start' }); });
  $('atr3').addEventListener('click', () => paso(1));
  $('forjaCta').addEventListener('click', () => {
    const resumen = 'Procesos atascados: ' + A.filter(x => sel.has(x[0])).map(x => x[1].toLowerCase()).join('; ') + '. Cómo queremos que nos reconozcan: ' + ras.join(', ').toLowerCase() + '.';
    const b = document.querySelector('[data-abrir]'); if (b) b.click();
    setTimeout(() => { const t = document.querySelector('#form textarea[name="tiempo"]'); if (t) t.value = resumen; }, 60);
  });
})();

(function(){
  const m = document.getElementById('cMin'); if (!m) return;
  const p = document.getElementById('cPer'), f = n => n.toLocaleString('es-ES', {maximumFractionDigits: 0});
  const calc = () => {
    const min = +m.value, per = +p.value, hPer = min * 220 / 60, hEq = hPer * per;
    document.getElementById('vMin').textContent = min; document.getElementById('vPer').textContent = per;
    document.getElementById('n1').textContent = min + ' min/día';
    document.getElementById('n2').textContent = f(hPer) + ' h/año';
    document.getElementById('n3').textContent = f(hEq) + ' h/año';
    document.getElementById('n4').textContent = f(hEq / 8) + ' jornadas';
  };
  m.addEventListener('input', calc); p.addEventListener('input', calc); calc();
  const nodos = document.querySelectorAll('.cnodo');
  const enciende = () => nodos.forEach((n, i) => setTimeout(() => n.classList.add('on'), 250 + i * 450));
  document.getElementById('sig2').addEventListener('click', () => { nodos.forEach(n => n.classList.remove('on')); setTimeout(enciende, 300); });
})();
