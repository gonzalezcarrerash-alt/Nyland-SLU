document.documentElement.classList.add('js');
(function(){
  // Apertura palabra a palabra
  const h1 = document.getElementById('frase');
  const walk = n => [...n.childNodes].forEach(c => {
    if (c.nodeType === 3) {
      const f = document.createDocumentFragment();
      c.textContent.split(/(\s+)/).forEach(t => { if (!t) return;
        if (/^\s+$/.test(t)) f.appendChild(document.createTextNode(t));
        else { const s = document.createElement('span'); s.className = 'w'; s.textContent = t; f.appendChild(s); } });
      c.replaceWith(f);
    } else walk(c);
  });
  walk(h1);
  h1.querySelectorAll('.w').forEach((w, i) => setTimeout(() => w.classList.add('on'), 300 + i * 190));

  // Revelados
  const todos = document.querySelectorAll('.rv, .paso');
  const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add('on'); io.unobserve(e.target); } }), { threshold: .2 });
  todos.forEach(el => io.observe(el));
  setTimeout(() => todos.forEach(el => el.classList.add('on')), 6000);


  // Progreso y halo
  const prog = document.getElementById('progreso'), halo = document.getElementById('halo');
  addEventListener('scroll', () => { const h = document.documentElement.scrollHeight - innerHeight; prog.style.setProperty('--p', h > 0 ? scrollY / h : 0); }, { passive: true });
  addEventListener('pointermove', e => { halo.style.setProperty('--mx', e.clientX + 'px'); halo.style.setProperty('--my', e.clientY + 'px'); }, { passive: true });

  // Ingeniería de procesos: antes / rediseñado
  const fd = document.getElementById('flujoDemo');
  fd.querySelectorAll('.fd-toggle button').forEach(b => b.addEventListener('click', () => {
    fd.dataset.modo = b.dataset.modo;
    fd.querySelectorAll('.fd-toggle button').forEach(x => x.classList.toggle('on', x === b));
  }));

  // Tarjetas del efecto miércoles
  document.querySelectorAll('.giro').forEach(g => g.addEventListener('click', () => {
    const on = g.classList.toggle('on'); g.setAttribute('aria-pressed', on);
  }));

  // Escalera de niveles: la línea se ilumina al bajar
  const esc = document.getElementById('escalera');
  const pintaEsc = () => { const r = esc.getBoundingClientRect(); const p = Math.min(1, Math.max(0, (innerHeight * .6 - r.top) / r.height)); esc.style.setProperty('--prog', p.toFixed(3)); };
  addEventListener('scroll', pintaEsc, { passive: true }); pintaEsc();

  // Cabecera
  const top = document.getElementById('top'); let last = 0;
  addEventListener('scroll', () => { const y = scrollY; top.classList.toggle('scrolled', y > 40); top.classList.toggle('hidden', y > 500 && y > last); last = y; }, { passive: true });

  // Pregunta
  const resp = document.getElementById('respuesta'), red = document.getElementById('red');
  document.querySelectorAll('.opcion').forEach(b => b.addEventListener('click', () => {
    document.querySelectorAll('.opcion').forEach(o => o.classList.remove('sel'));
    b.classList.add('sel'); resp.classList.remove('on');
    setTimeout(() => { resp.classList.add('on'); red.classList.add('on'); }, 120);
  }));

  // Carrusel
  const pista = document.getElementById('pistaC'), puntos = [...document.querySelectorAll('#puntos i')];
  const diapos = [...pista.children];
  const actual = () => { const c = pista.scrollLeft + pista.clientWidth / 2; let best = 0, d = 1e9;
    diapos.forEach((s, i) => { const m = s.offsetLeft + s.clientWidth / 2; if (Math.abs(m - c) < d) { d = Math.abs(m - c); best = i; } }); return best; };
  const ir = i => { const s = diapos[(i + diapos.length) % diapos.length]; pista.scrollTo({ left: s.offsetLeft - (pista.clientWidth - s.clientWidth) / 2, behavior: 'smooth' }); };
  pista.addEventListener('scroll', () => { const a = actual(); puntos.forEach((p, i) => p.classList.toggle('on', i === a)); }, { passive: true });
  document.querySelectorAll('.flechas button').forEach(b => b.addEventListener('click', () => ir(actual() + +b.dataset.dir)));
  let auto = setInterval(() => ir(actual() + 1), 5000);
  pista.addEventListener('pointerdown', () => clearInterval(auto), { once: true });

  // Antes / Después
  const comp = document.getElementById('comp');
  comp.querySelector('input').addEventListener('input', e => comp.style.setProperty('--x', e.target.value + '%'));

  // FAQ
  const fe = document.getElementById('faq-equipo');
  fe.addEventListener('toggle', () => { const m = fe.querySelector('.faq-mascota'); if (fe.open) { m.style.animation = 'none'; m.offsetHeight; m.style.animation = ''; } });

  // Formulario simulado
  const modal = document.getElementById('modal'), form = document.getElementById('form');
  const pForm = document.getElementById('paso-form'), pOk = document.getElementById('paso-ok'), err = document.getElementById('error');
  let lastFocus = null;
  const abrir = () => { lastFocus = document.activeElement; pForm.style.display = ''; pOk.style.display = 'none'; err.textContent = ''; form.reset();
    modal.classList.add('open'); document.body.style.overflow = 'hidden'; setTimeout(() => form.querySelector('input').focus({ preventScroll: true }), 300); };
  const cerrar = () => { modal.classList.remove('open'); document.body.style.overflow = ''; lastFocus && lastFocus.focus(); };
  document.querySelectorAll('[data-abrir]').forEach(b => b.addEventListener('click', abrir));
  modal.addEventListener('click', e => { if (e.target === modal || e.target.closest('[data-cerrar]')) cerrar(); });
  addEventListener('keydown', e => { if (e.key === 'Escape' && modal.classList.contains('open')) cerrar(); });
  form.addEventListener('submit', e => { e.preventDefault(); const f = form.elements;
    if (!f.nombre.value.trim() || !f.empresa.value.trim() || !f.sector.value || !f.contacto.value.trim()) { err.textContent = 'Completa los campos obligatorios, por favor.'; return; }
    if (!f.rgpd.checked) { err.textContent = 'Necesitamos que aceptes la política de privacidad.'; return; }
    const cuerpo = `Nombre: ${f.nombre.value.trim()}
Empresa: ${f.empresa.value.trim()}
Sector: ${f.sector.value}
Contacto: ${f.contacto.value.trim()}

Lo que más tiempo le quita al equipo:
${f.tiempo.value.trim()}`;
    location.href = 'mailto:contacto@nylandconsulting.es?subject=' + encodeURIComponent('Solicitud de diagnóstico · ' + f.empresa.value.trim()) + '&body=' + encodeURIComponent(cuerpo);
    pForm.style.display = 'none'; pOk.style.display = 'block'; });
})();
